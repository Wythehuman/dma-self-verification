
document.getElementById("verifyForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const nrc = document.getElementById("nrc").value;
    const cert = document.getElementById("cert").value;

    // Dummy check
    if (name && nrc && cert) {
        document.getElementById("result").innerText = 
            `Verified: ${name}, ${nrc}, Certificate: ${cert}`;
    } else {
        document.getElementById("result").innerText = "Please fill all fields.";
    }
});
